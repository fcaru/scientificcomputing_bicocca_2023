## Module for scientific computing class exercise

The module features the exercise on game of life